# API_Validation_v1 (엔드포인트별 검증/오류/성능)

## 공통
- 시간 포맷: ISO8601 UTC("2025-08-10T09:00:00Z")
- 에러 포맷:
{
  "code":"...", "message":"...", "details":{...},
  "traceId":"...", "timestamp":"...", "path":"/...", "method":"POST"
}

## POST /work-orders (지시 생성)
- 권한: ROLE_OP+
- 필드 검증
  - workOrderNumber: 필수, UK
  - itemId/processId/equipmentId: FK 존재
  - orderQty: number, ≥0
- 오류: VALIDATION_ERROR(400), DUPLICATE_KEY(409), FORBIDDEN(403)

## PUT /work-orders/{id}/status (상태 전이)
- 권한: ROLE_OP+
- 필드 검증
  - toStatus ∈ {R,C}
  - 전이표 준수(P→R, R→C)
- 오류: WO_STATUS_INVALID(400), FORBIDDEN(403)

## POST /equip-status (RUN 등록)
- 권한: ROLE_OP+
- 필드 검증
  - equipmentId: FK
  - statusCode ∈ {RUN,IDLE,DOWN}
  - startTimeUtc: 필수
  - endTimeUtc: 선택, 있으면 end≥start
- 오류: TIME_ORDER_INVALID(400), VALIDATION_ERROR(400), CODE_INACTIVE(400)

## POST /performances (실적 등록)
- 권한: ROLE_OP+
- 필드 검증
  - workOrderId: FK, WO 상태=R
  - producedQty: number, ≥0
  - defectQty: number, 0≤defect≤produced
  - startTime/endTime: end≥start
- Tx: PERF insert → WO 누적 생산/불량 합산 갱신(한 Tx)
- 오류: VALIDATION_ERROR(400), TIME_ORDER_INVALID(400), FORBIDDEN(403)

## GET /kpi/actuals (목표 vs 실적)
- 권한: ROLE_OP/QA/ADMIN
- 파라미터: kpiDate, equipmentId (필수)
- 성능: SLA P95<500ms, EXPLAIN range 사용
