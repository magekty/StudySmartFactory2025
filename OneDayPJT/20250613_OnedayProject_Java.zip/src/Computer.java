public interface Computer{
    void showDetails();
}