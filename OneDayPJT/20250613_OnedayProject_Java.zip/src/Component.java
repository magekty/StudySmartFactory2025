interface Component {
    void print(int depth);
}
